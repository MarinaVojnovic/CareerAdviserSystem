package com.sbnz.career.adviser.enums;

public enum IdentityEnum{
	ASSERTIVE,
	TURBULENT
}
