package com.sbnz.career.adviser.enums;

public enum TacticsEnum{
	JUDGING,
	PROSPECTING
}
