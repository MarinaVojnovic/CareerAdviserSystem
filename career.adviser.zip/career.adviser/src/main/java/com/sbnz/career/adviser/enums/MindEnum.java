package com.sbnz.career.adviser.enums;

public enum MindEnum{

	EXTRAVERTED,
	INTROVERTED
}
