package com.sbnz.career.adviser.enums;

public enum EnergyEnum{
	REALIST,
	VISIONARY
}
