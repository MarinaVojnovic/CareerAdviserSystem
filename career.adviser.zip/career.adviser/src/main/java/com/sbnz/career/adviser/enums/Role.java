package com.sbnz.career.adviser.enums;

public enum Role {

	ROLE_ADMIN, ROLE_USER
}
