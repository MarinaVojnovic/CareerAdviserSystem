package com.sbnz.career.adviser.enums;

public enum NatureEnum{
	THINKING,
	FEELING
}
