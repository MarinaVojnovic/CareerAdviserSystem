package com.sbnz.career.adviser.service;

import java.util.List;

import com.sbnz.career.adviser.entity.PreferenceQuestionResult;

public interface PreferenceQuestionResultService {

	void submitPreferenceQuestionResults(List<PreferenceQuestionResult> prefQuestResults);
}
