package com.sbnz.career.adviser.service;

import com.sbnz.career.adviser.model.Criteriums;
import com.sbnz.career.adviser.model.RecommendedProfessions;

public interface ResultsService {

	
}
