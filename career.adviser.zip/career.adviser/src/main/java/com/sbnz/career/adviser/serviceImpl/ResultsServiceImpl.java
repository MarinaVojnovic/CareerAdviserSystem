package com.sbnz.career.adviser.serviceImpl;

import org.springframework.stereotype.Service;

import com.sbnz.career.adviser.model.Criteriums;
import com.sbnz.career.adviser.model.RecommendedProfessions;
import com.sbnz.career.adviser.service.ResultsService;

@Service
public class ResultsServiceImpl implements ResultsService{

	

}
